export const groups = [
  {
    id: crypto.randomUUID(),
    title: "OpenMic Friends",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.",
  },
  {
    id: crypto.randomUUID(),
    title: "UX StudyCircle",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.",
  },
  {
    id: crypto.randomUUID(),
    title: "LanguageExchange",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.",
  },
  {
    id: crypto.randomUUID(),
    title: "VeganRecipeSwap",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.",
  },
];
